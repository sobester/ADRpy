Aircraft Design Recipes in Python
===============================

version number: 0.0.1
author: Andras Sobester

Overview
--------

A Python library of aircraft conceptual design tools.

Installation / Usage
--------------------

To install use pip:

    $ pip install ADRpy


Or clone the repo:

    $ git clone https://github.com/sobester/ADRpy.git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD